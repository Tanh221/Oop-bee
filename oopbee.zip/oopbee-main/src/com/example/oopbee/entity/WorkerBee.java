package com.example.oopbee.entity;

public class WorkerBee extends Bee {

    public WorkerBee() {
        super();// call base class (Bee) constructor
        this.setType("Worker");
    }
}