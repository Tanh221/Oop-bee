package com.example.oopbee.entity;

public class QueenBee extends Bee {

    public QueenBee() {
        super();// call base class (Bee) constructor
        this.setType("Queen");
    }
}