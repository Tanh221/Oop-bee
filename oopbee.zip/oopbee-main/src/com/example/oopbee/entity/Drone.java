package com.example.oopbee.entity;

public class Drone extends Bee {
    public Drone(){
        super();//call base class (Bee) constructor
        this.setType("Drone");
    }
}

